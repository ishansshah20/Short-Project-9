Short Project 9

Files in the folder;

1. MST.java
2. BinaryHeap.java
3. Graph.java

How to compile and run:

1. Unzip the folder and generate the class files
2. The main function is inside of the MST.java
3. In the terminal, inside the unzipped folder, type following code to compile all the file
	- javac ./ixs180019/*.java
4. Type java ixs180019.MST for the code execution. Arguements should be passed in the following order: <File to be executed>
